import mongoose from "mongoose";

const storeSchema = new mongoose.Schema({
  shop: {
    type: String,
    required: true,
    unique: true,
  },

  accessToken: {
    type: String,
  },

  ownerEmail: {
    type: String,
  },

  installed: {
    type: Boolean,
    default: true,
  },

  lastSync: {
    type: Date,
    default: null,
  },

  plan: {
    type: String,
    default: "free",
  },

  createdAt: {
    type: Date,
    default: Date.now,
  }
});

// ✅ Fix OverwriteModelError
export default mongoose.models.Store || mongoose.model("Store", storeSchema);
