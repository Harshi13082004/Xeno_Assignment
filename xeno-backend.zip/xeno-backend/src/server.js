import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import cookieParser from "cookie-parser";
import connectDB from "./config/db.js";

import authRoutes from "./routes/auth.routes.js";
import apiRoutes from "./routes/api.routes.js";
import shopifyRoutes from "./routes/shopify.routes.js";

dotenv.config();
connectDB();

const app = express();

// Required for Shopify + ngrok
app.enable("trust proxy");

// Cookies required for Shopify Admin iframe
app.use(cookieParser());
app.use((req, res, next) => {
  res.cookie("app_session", "active", {
    httpOnly: false,
    secure: true,       // required for https
    sameSite: "none",
  });
  next();
});

// Allow cross-origin
app.use(cors({ origin: "*", credentials: true }));
app.use(express.json());

// =======================
// ROUTES
// =======================

// Shopify OAuth
app.use("/shopify", shopifyRoutes);

// Authentication (Register + Login)
app.use("/auth", authRoutes);

// Protected APIs (dashboard, sync, jobs, products, settings)
app.use("/api", apiRoutes);

// Health check
app.get("/", (req, res) => {
  res.send("✅ Xeno Backend Running");
});

// =======================
// START SERVER
// =======================
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Backend running on port ${PORT}`));
