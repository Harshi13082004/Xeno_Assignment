export const login = (req, res) => {
  res.json({ message: "Login API working" });
};

export const signup = (req, res) => {
  res.json({ message: "Signup API working" });
};
