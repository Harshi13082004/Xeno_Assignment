import express from "express";
import axios from "axios";
import Store from "../models/store.model.js";
import dotenv from "dotenv";
dotenv.config();

const router = express.Router();

const {
  SHOPIFY_API_KEY,
  SHOPIFY_API_SECRET,
  BACKEND_URL,
  SCOPES
} = process.env;

// ================================
// 1️⃣ INSTALL ROUTE
// ================================
router.get("/install", async (req, res) => {
  const { shop } = req.query;

  if (!shop) return res.status(400).send("Shop parameter missing");

  const redirectUri = `${BACKEND_URL}/shopify/callback`;
  const state = Math.random().toString(36).substring(7);

  const installUrl =
    `https://${shop}/admin/oauth/authorize` +
    `?client_id=${SHOPIFY_API_KEY}` +
    `&scope=${SCOPES}` +
    `&redirect_uri=${redirectUri}` +
    `&state=${state}` +
    `&grant_options[]=offline`;

  return res.redirect(installUrl);
});

// ================================
// 2️⃣ CALLBACK ROUTE
// ================================
router.get("/callback", async (req, res) => {
  const { shop, code } = req.query;

  if (!shop || !code) {
    return res.status(400).send("Missing shop or code");
  }

  try {
    // Exchange code for access token
    const tokenResponse = await axios.post(
      `https://${shop}/admin/oauth/access_token`,
      {
        client_id: SHOPIFY_API_KEY,
        client_secret: SHOPIFY_API_SECRET,
        code
      }
    );

    const accessToken = tokenResponse.data.access_token;

    // Save store in DB
    await Store.findOneAndUpdate(
      { shop },
      { shop, accessToken, installed: true },
      { upsert: true, new: true }
    );

    // Redirect to your app inside Shopify Admin
    return res.send(`
  <html>
    <body>
      <script>
        window.top.location.href = "https://${shop}/admin/apps/39c0229ac19f06b0acdc3614f21a7ad4";
      </script>
    </body>
  </html>
`);


  } catch (err) {
    console.error("Callback Error:", err.response?.data || err);
    res.status(500).send("Error during Shopify OAuth");
  }
});

export default router;
