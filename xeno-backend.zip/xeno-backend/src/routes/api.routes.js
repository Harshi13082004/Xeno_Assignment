import express from "express";
import authMiddleware from "../middleware/auth.middleware.js";
import Store from "../models/Store.model.js";

const router = express.Router();

/** =============================
 *  🔹 DASHBOARD API
 *  ============================= */
router.get("/dashboard", authMiddleware, (req, res) => {
  res.json({
    stats: [
      { title: "Total Stores", value: 12 },
      { title: "Active Jobs", value: 4 },
      { title: "Pending Webhooks", value: 3 },
      { title: "Products Synced", value: 842 },
    ],
    activity: [
      { event: "Products Synced", status: "Success", time: "11:30 AM" },
      { event: "Webhook Received", status: "Success", time: "10:45 AM" },
      { event: "Job Triggered", status: "Pending", time: "Yesterday" },
    ],
  });
});

/** =============================
 *  🔹 SYNC API
 *  ============================= */
router.get("/sync", authMiddleware, (req, res) => {
  res.json({
    syncStats: [
      { title: "Products Synced", value: "842" },
      { title: "Pending Items", value: "14" },
      { title: "Last Sync", value: "Today, 11:30 AM" },
    ],
    logs: [
      { id: 1, message: "Started product sync", time: "11:30 AM" },
      { id: 2, message: "Fetched data from Shopify", time: "11:31 AM" },
      { id: 3, message: "Synced 842 products", time: "11:32 AM" },
    ],
  });
});

/** =============================
 *  🔹 JOBS API
 *  ============================= */
router.get("/jobs", authMiddleware, (req, res) => {
  res.json({
    jobs: [
      { id: 1, name: "Sync Products", status: "Running", time: "2 mins ago" },
      { id: 2, name: "Update Inventory", status: "Completed", time: "10 mins ago" },
      { id: 3, name: "Sync Webhooks", status: "Failed", time: "20 mins ago" },
    ],
  });
});

/** =============================
 *  🔹 WEBHOOKS API
 *  ============================= */
router.get("/webhooks", authMiddleware, (req, res) => {
  res.json({
    webhooks: [
      { id: 1, event: "order_created", status: "Delivered" },
      { id: 2, event: "product_updated", status: "Queued" },
    ],
  });
});

/** =============================
 *  🔹 PRODUCTS API
 *  ============================= */
router.get("/products", authMiddleware, (req, res) => {
  res.json({
    products: [
      { id: 101, name: "T-Shirt", stock: 34 },
      { id: 102, name: "Sneakers", stock: 12 },
      { id: 103, name: "Backpack", stock: 58 },
    ],
  });
});

/** =============================
 *  🔹 SETTINGS API
 *  ============================= */
// Settings - Get current settings
router.get("/settings", authMiddleware, (req, res) => {
  res.json({
    storeName: "Demo Store",
    apiKey: "ABC123XYZ",
  });
});

// Settings - Update settings
router.post("/settings", authMiddleware, (req, res) => {
  const { storeName, apiKey } = req.body;

  res.json({
    message: "Settings saved successfully",
    storeName,
    apiKey,
  });
});




router.post("/test-store", async (req, res) => {
  try {
    const store = await Store.create({
      shop: "my-test-store.myshopify.com",
      accessToken: "test_token_123",
      ownerEmail: "owner@example.com",
    });

    res.json(store);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
