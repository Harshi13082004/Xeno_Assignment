import { useEffect, useState } from "react";
import "./Dashboard.css";

export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [apiData, setApiData] = useState(null);

  // Your existing UI data remains
  const stats = [
    { title: "Total Stores", value: "12" },
    { title: "Active Jobs", value: "4" },
    { title: "Pending Webhooks", value: "3" },
    { title: "Products Synced", value: "842" },
  ];

  const activity = [
    { event: "Products Synced", status: "Success", time: "11:30 AM" },
    { event: "Webhook Received", status: "Success", time: "10:45 AM" },
    { event: "Job Triggered", status: "Pending", time: "Yesterday" },
  ];

  // ---- Fetch backend dashboard API ----
  useEffect(() => {
    async function loadDashboard() {
      try {
        const token = localStorage.getItem("token");

        const res = await fetch("http://localhost:5000/api/dashboard", {
          headers: { Authorization: `Bearer ${token}` },
        });

        const result = await res.json();
        setApiData(result);
      } catch (err) {
        console.error("Dashboard API error:", err);
      } finally {
        setLoading(false);
      }
    }

    loadDashboard();
  }, []);

  if (loading) return <p>Loading Dashboard...</p>;

  return (
    <div className="dashboard-container">
      <h2 className="dashboard-title">Dashboard Overview</h2>

      {/* Backend message (optional for testing) */}
      {apiData && (
        <p style={{ background: "#eef", padding: "8px", borderRadius: "6px" }}>
          API Message: {apiData.message}
        </p>
      )}

      {/* Your existing Stats */}
      <div className="stats-grid">
        {stats.map((item, index) => (
          <div key={index} className="stat-card">
            <h3>{item.title}</h3>
            <p>{item.value}</p>
          </div>
        ))}
      </div>

      {/* Recent Activity */}
      <h3 className="section-title">Recent Activity</h3>
      <div className="activity-box">
        {activity.map((row, idx) => (
          <div key={idx} className="activity-row">
            <div>{row.event}</div>
            <div className={`status ${row.status.toLowerCase()}`}>
              {row.status}
            </div>
            <div className="time">{row.time}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
