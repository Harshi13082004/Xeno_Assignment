import { useEffect, useState } from "react";
import "./Webhooks.css";

export default function Webhooks() {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    async function fetchLogs() {
      try {
        const token = localStorage.getItem("token");

        const res = await fetch("http://localhost:5000/api/webhooks", {
          headers: { Authorization: `Bearer ${token}` },
        });

        const data = await res.json();
        setLogs(data.logs || []);
      } catch (err) {
        console.error("Failed to fetch webhook logs", err);
      }
    }

    fetchLogs();
  }, []);

  return (
    <div className="webhooks-container">
      <h2 className="page-title">Webhook Logs</h2>

      <table className="webhook-table">
        <thead>
          <tr>
            <th>Endpoint</th>
            <th>Status</th>
            <th>Received At</th>
          </tr>
        </thead>

        <tbody>
          {logs.map((log) => (
            <tr key={log.id}>
              <td>{log.endpoint}</td>
              <td>
                <span className={`status-badge ${log.status.toLowerCase()}`}>
                  {log.status}
                </span>
              </td>
              <td>{log.time}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
