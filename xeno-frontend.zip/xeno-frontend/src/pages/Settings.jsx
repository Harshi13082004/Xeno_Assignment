import "./Settings.css";

export default function Settings() {
  return (
    <div className="settings-container">
      <h2 className="page-title">Settings</h2>

      <div className="settings-card">
        <h3>Store Configuration</h3>

        <label>Store Name</label>
        <input type="text" placeholder="Enter store name" />

        <label>API Key</label>
        <input type="text" placeholder="Enter API key" />

        <button className="save-btn">Save Changes</button>
      </div>
    </div>
  );
}
