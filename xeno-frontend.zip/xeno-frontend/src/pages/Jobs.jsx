import { useEffect, useState } from "react";
import "./Jobs.css";

export default function Jobs() {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    async function fetchJobs() {
      try {
        const token = localStorage.getItem("token");

        const res = await fetch("http://localhost:5000/api/jobs", {
          headers: { Authorization: `Bearer ${token}` },
        });

        const data = await res.json();
        setJobs(data.jobs || []);
      } catch (err) {
        console.error("Failed to fetch jobs", err);
      }
    }

    fetchJobs();
  }, []);

  return (
    <div className="jobs-container">
      <h2 className="page-title">Jobs</h2>

      {/* Filters */}
      <div className="filters">
        <button className="filter-btn active">All</button>
        <button className="filter-btn">Running</button>
        <button className="filter-btn">Completed</button>
        <button className="filter-btn">Failed</button>
      </div>

      {/* Table */}
      <table className="jobs-table">
        <thead>
          <tr>
            <th>Job Name</th>
            <th>Status</th>
            <th>Last Run</th>
          </tr>
        </thead>

        <tbody>
          {jobs.map((job) => (
            <tr key={job.id}>
              <td>{job.name}</td>
              <td>
                <span className={`status-badge ${job.status.toLowerCase()}`}>
                  {job.status}
                </span>
              </td>
              <td>{job.time}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
