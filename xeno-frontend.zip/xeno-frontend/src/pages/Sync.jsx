import { useEffect, useState } from "react";
import "./Sync.css";

export default function Sync() {
  const [loading, setLoading] = useState(true);
  const [apiData, setApiData] = useState(null);

  useEffect(() => {
    async function fetchSyncData() {
      try {
        const token = localStorage.getItem("token");

        const res = await fetch("http://localhost:5000/api/sync", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        const data = await res.json();
        setApiData(data);
      } catch (err) {
        console.error("Sync API error:", err);
      } finally {
        setLoading(false);
      }
    }

    fetchSyncData();
  }, []);

  if (loading) return <p>Loading sync data...</p>;

  // fallback if backend does not give some fields
  const syncStats = [
    { title: "Products Synced", value: apiData?.totalSynced || "0" },
    { title: "Pending Items", value: "14" },
    { title: "Last Sync", value: apiData?.lastSync || "N/A" },
  ];

  const logs = [
    { id: 1, message: apiData?.message || "Sync message", time: apiData?.lastSync || "" },
    { id: 2, message: "Fetched data from Shopify", time: "11:31 AM" },
    { id: 3, message: `Synced ${apiData?.totalSynced || 0} products`, time: apiData?.lastSync || "" },
  ];

  return (
    <div className="sync-container">
      <h2 className="page-title">Sync Center</h2>

      {/* Stats Section */}
      <div className="sync-stats">
        {syncStats.map((stat, index) => (
          <div key={index} className="sync-card">
            <h4>{stat.title}</h4>
            <p>{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Sync Buttons */}
      <div className="sync-buttons">
        <button className="btn primary">Run Full Sync</button>
        <button className="btn secondary">Run Inventory Sync</button>
        <button className="btn secondary">Run Price Sync</button>
      </div>

      {/* Log Section */}
      <div className="log-box">
        <h3>Sync Logs</h3>

        {logs.map((log) => (
          <div key={log.id} className="log-entry">
            <p>{log.message}</p>
            <span>{log.time}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
