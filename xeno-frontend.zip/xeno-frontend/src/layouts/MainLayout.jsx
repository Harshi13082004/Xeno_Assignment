import { Outlet, Link, useLocation } from "react-router-dom";
import "./MainLayout.css";

export default function MainLayout() {
  const location = useLocation();

  const menu = [
    { path: "/dashboard", label: "Dashboard" },
    { path: "/sync", label: "Sync" },
    { path: "/jobs", label: "Jobs" },
    { path: "/webhooks", label: "Webhooks" },
    { path: "/products", label: "Products" },
    { path: "/settings", label: "Settings" },
  ];

  return (
    <div className="layout-container">
      {/* Sidebar */}
      <aside className="sidebar">
        <h2 className="logo">Xeno Panel</h2>
        <nav>
          {menu.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={
                location.pathname.startsWith(item.path)
                  ? "active link"
                  : "link"
              }
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>

      {/* Main Content */}
      <main className="content">
        {/* Top Navbar */}
        <header className="navbar">
          <h3>Welcome!</h3>
        </header>

        {/* Render page content */}
        <div className="page-content">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
