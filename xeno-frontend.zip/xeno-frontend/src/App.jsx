import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import MainLayout from "./layouts/MainLayout.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";
import Sync from "./pages/Sync.jsx";

// IMPORT ALL OTHER PAGES HERE
import Jobs from "./pages/Jobs.jsx";
import Webhooks from "./pages/Webhooks.jsx";
import Products from "./pages/Products.jsx";
import Settings from "./pages/Settings.jsx";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public Login */}
        <Route path="/" element={<Login />} />

        {/* Protected Section */}
        <Route
          element={
            <ProtectedRoute>
              <MainLayout />
            </ProtectedRoute>
          }
        >
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/sync" element={<Sync />} />
          <Route path="/jobs" element={<Jobs />} />
          <Route path="/webhooks" element={<Webhooks />} />
          <Route path="/products" element={<Products />} />
          <Route path="/settings" element={<Settings />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
